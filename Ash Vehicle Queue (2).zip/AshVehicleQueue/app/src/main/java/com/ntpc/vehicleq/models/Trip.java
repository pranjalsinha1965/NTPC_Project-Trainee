package com.ntpc.vehicleq.models;

public class Trip {
    private int id;
    private int queue_no;
    private int capacity;
    private int am_ven_unique_id;
    private int am_ven_veh_slno;
    private int am_ven_veh_unique_id;
    private String am_ven_name;
    private String am_ven_veh_number;
    private String am_ven_veh_type;
    private String requested_on;
    private String am_ven_veh_status;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getQueue_no() {
        return queue_no;
    }

    public void setQueue_no(int queue_no) {
        this.queue_no = queue_no;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getAm_ven_unique_id() {
        return am_ven_unique_id;
    }

    public void setAm_ven_unique_id(int am_ven_unique_id) {
        this.am_ven_unique_id = am_ven_unique_id;
    }

    public int getAm_ven_veh_unique_id() {
        return am_ven_veh_unique_id;
    }

    public void setAm_ven_veh_unique_id(int am_ven_veh_unique_id) {
        this.am_ven_veh_unique_id = am_ven_veh_unique_id;
    }

    public int getAm_ven_veh_slno() {
        return am_ven_veh_slno;
    }

    public void setAm_ven_veh_slno(int am_ven_veh_slno) {
        this.am_ven_veh_slno = am_ven_veh_slno;
    }

    public String getAm_ven_name() {
        return am_ven_name;
    }

    public void setAm_ven_name(String am_ven_name) {
        this.am_ven_name = am_ven_name;
    }

    public String getAm_ven_veh_number() {
        return am_ven_veh_number;
    }

    public void setAm_ven_veh_number(String am_ven_veh_number) {
        this.am_ven_veh_number = am_ven_veh_number;
    }

    public String getAm_ven_veh_type() {
        return am_ven_veh_type;
    }

    public void setAm_ven_veh_type(String am_ven_veh_type) {
        this.am_ven_veh_type = am_ven_veh_type;
    }

    public String getRequested_on() {
        return requested_on;
    }

    public void setRequested_on(String requested_on) {
        this.requested_on = requested_on;
    }

    public String getAm_ven_veh_status() {
        return am_ven_veh_status;
    }

    public void setAm_ven_veh_status(String am_ven_veh_status) {
        this.am_ven_veh_status = am_ven_veh_status;
    }
}
