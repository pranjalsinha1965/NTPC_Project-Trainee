package com.ntpc.vehicleq;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatImageView;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.JsonWriter;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.ntpc.vehicleq.helpers.AppSharedPreferences;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONStringer;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {
    int backButtonCount = 0;
    AppCompatButton btnLogin;
    AppCompatImageView imgLoader;
    TextInputEditText txtUsername;
    AppSharedPreferences appConfig;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();
        appConfig = new AppSharedPreferences(getApplicationContext());
        txtUsername = findViewById(R.id.txt_user_name);
        imgLoader = findViewById(R.id.loader);
        // txtPassword = findViewById(R.id.txt_password);
        Glide.with(this)
                        .load(R.raw.loader)
                                .into(imgLoader);
        imgLoader.setVisibility(View.GONE);
        btnLogin = findViewById(R.id.button_login);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imgLoader.setVisibility(View.VISIBLE);
                btnLogin.setVisibility(View.GONE);
                if (TextUtils.isEmpty(txtUsername.getText().toString().trim())) {
                    Snackbar.make(view, "Please Enter Valid UNIQUE ID", Snackbar.LENGTH_SHORT).show();
                    txtUsername.setFocusable(true);
                    imgLoader.setVisibility(View.GONE);
                    btnLogin.setVisibility(View.VISIBLE);
                    return;
                }
/*                if (TextUtils.isEmpty(txtPassword.getText().toString().trim())) {
                    Snackbar.make(view, "Please Enter Valid Mobile Number", Snackbar.LENGTH_SHORT).show();
                    txtPassword.setFocusable(true);
                    return;
                }*/
                postData(view);
                //postJSONData(view);
           }
        });
    }


    public void postData(View view) {
        //String REGISTER_URL =    "http://43.227.135.110:3233/app/login";
        String REGISTER_URL = "http://10.10.11.68:8080/app/checkvendor";
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest stringRequest = new StringRequest(Request.Method.POST, REGISTER_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        String str2 = "mobile";
                        Log.d("Login Response: ", response);
                        try {
                            JSONObject jSONObject = new JSONObject(response);
                            if (jSONObject.getBoolean("status")) {
                                appConfig.setAshId(txtUsername.getText().toString());
                                try {
                                    if (jSONObject.getJSONObject("vendor") != null) {
                                        Intent intent = new Intent(LoginActivity.this, PasswordActivity.class);
                                        appConfig.setMobile(jSONObject.getString("mobile").trim());
                                        imgLoader.setVisibility(View.GONE);
                                        startActivity(intent);
                                    } else {
                                        Intent intent2 = new Intent(LoginActivity.this, OTPActivity.class);
                                        appConfig.setMobile(jSONObject.getString("mobile").trim());
                                        imgLoader.setVisibility(View.GONE);
                                        startActivity(intent2);
                                    }
                                } catch (Exception unused) {
                                    Intent intent3 = new Intent(LoginActivity.this, OTPActivity.class);
                                    appConfig.setMobile(jSONObject.getString("mobile").trim());
                                    imgLoader.setVisibility(View.GONE);
                                    startActivity(intent3);
                                }
                            } else {
                                imgLoader.setVisibility(View.GONE);
                                btnLogin.setVisibility(View.VISIBLE);
                                String string = jSONObject.getString("vendor");
                                Toast.makeText(LoginActivity.this, string, Toast.LENGTH_LONG).show();
                            }
                        } catch (Exception e) {
                            imgLoader.setVisibility(View.GONE);
                            btnLogin.setVisibility(View.VISIBLE);
                            Toast.makeText(LoginActivity.this, e.toString(), Toast.LENGTH_LONG).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(LoginActivity.this,error.toString(),Toast.LENGTH_LONG).show();
                        imgLoader.setVisibility(View.GONE);
                        btnLogin.setVisibility(View.VISIBLE);
                        //Snackbar.make(view, error.toString(), Snackbar.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("UserName", txtUsername.getText().toString().trim());
                //params.put("Password", txtPassword.getText().toString().trim());
                params.put("device_id", appConfig.getDeviceID());

                return params;
            }

        };
        requestQueue.add(stringRequest);

    }


    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (this.backButtonCount >= 1) {
            Intent intent = new Intent("android.intent.action.MAIN");
            intent.addCategory("android.intent.category.HOME");
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            return;
        }
        Toast.makeText(this, "Press the back button once again to close the application.", Toast.LENGTH_SHORT).show();
        this.backButtonCount++;
    }

}