package com.ntpc.vehicleq;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.ntpc.vehicleq.adapters.NewRequestVehiclesAdapter;
import com.ntpc.vehicleq.adapters.TripsAdapter;
import com.ntpc.vehicleq.helpers.AppSharedPreferences;
import com.ntpc.vehicleq.models.Trip;
import com.ntpc.vehicleq.models.Vehicles;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StatusActivity extends AppCompatActivity implements TripsAdapter.OnTripCancel {
    AppSharedPreferences appConfig;
    AppCompatImageView imgLoader;
    List<Trip> tripsList = new ArrayList<>();
    TripsAdapter tripsAdapter;
    RecyclerView tripsRecyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status);
        appConfig = new AppSharedPreferences(getApplicationContext());
        imgLoader = findViewById(R.id.loader);
        Glide.with(this)
                .load(R.raw.loader)
                .into(imgLoader);
        tripsRecyclerView = findViewById(R.id.recyclerview_current_trips);
        imgLoader.setVisibility(View.GONE);
        getVehicles();
    }

    public void getVehicles() {
        imgLoader.setVisibility(View.VISIBLE);
        //String REGISTER_URL =    "http://43.227.135.110:3233/app/currenttrips?uid="+appConfig.getVendorUID();
        String REGISTER_URL =    "http://10.10.11.68:8080/app/currenttrips?uid="+appConfig.getVendorUID();
        Log.d("Vehicles URL: ",REGISTER_URL);
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest stringRequest = new StringRequest(Request.Method.GET, REGISTER_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            Log.d("Vehicles Response: ",response);
                            JSONObject obj = new JSONObject(response);
                            if(obj.getBoolean("status")){


                                JSONArray objVehicles = obj.getJSONArray("vendor");
                                for (int i=0;i<objVehicles.length();i++){
                                    JSONObject jsonVehicle = objVehicles.getJSONObject(i);
                                    Trip trp =new Trip();
                                    trp.setAm_ven_name(jsonVehicle.getString("am_ven_name"));
                                    trp.setAm_ven_unique_id(jsonVehicle.getInt("am_ven_unique_id"));
                                    trp.setAm_ven_veh_slno(jsonVehicle.getInt("am_ven_veh_slno"));
                                    trp.setAm_ven_veh_unique_id(jsonVehicle.getInt("am_ven_veh_unique_id"));
                                    trp.setAm_ven_veh_number(jsonVehicle.getString("am_ven_veh_number"));
                                    trp.setAm_ven_veh_status(jsonVehicle.getString("am_ven_veh_status"));
                                    trp.setAm_ven_veh_type(jsonVehicle.getString("am_ven_veh_type"));
                                    trp.setCapacity(jsonVehicle.getInt("capacity"));
                                    trp.setId(jsonVehicle.getInt("id"));
                                    trp.setQueue_no(jsonVehicle.getInt("queue_no"));
                                    trp.setRequested_on(jsonVehicle.getString("slot_time"));
                                    if(jsonVehicle.getString("am_ven_veh_status").equals("ON")){

                                    }
                                        tripsList.add(trp);
                                }
                                //tripsAdapter = new TripsAdapter(getApplicationContext(),tripsList,StatusActivity.this::onTripCancel);
                                tripsAdapter = new TripsAdapter(StatusActivity.this,tripsList,StatusActivity.this::onTripCancel);
                                tripsRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                                tripsRecyclerView.setAdapter(tripsAdapter);
                                imgLoader.setVisibility(View.GONE);
                            }
                            else{
                                //Snackbar.make(view, obj.getString("message"), Snackbar.LENGTH_SHORT).show();
                                Toast.makeText(StatusActivity.this,obj.getString("message"),Toast.LENGTH_LONG).show();
                                imgLoader.setVisibility(View.GONE);
                            }

                        } catch (JSONException e) {
                            //Snackbar.make(view, e.toString(), Snackbar.LENGTH_SHORT).show();
                            Toast.makeText(StatusActivity.this,e.toString(),Toast.LENGTH_LONG).show();
                            imgLoader.setVisibility(View.GONE);
                        }

                        // Toast.makeText(RequestActivity.this,response,Toast.LENGTH_LONG).show();

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(StatusActivity.this,error.toString(),Toast.LENGTH_LONG).show();
                        imgLoader.setVisibility(View.GONE);
                        //Snackbar.make(view, error.toString(), Snackbar.LENGTH_SHORT).show();
                    }
                })
   /*     {
            @Override
            protected Map<String,String> getParams(){
                Map<String,String> params = new HashMap<String, String>();
                params.put("UserName",txtUsername.getText().toString().trim());
                params.put("Password",txtPassword.getText().toString().trim());

                return params;
            }

        }*/
                ;


        requestQueue.add(stringRequest);
    }

    @Override
    public void onTripCancel(int position) {
        cancelRequest(position);
    }

    public void cancelRequest(int position) {
        Trip trip = tripsAdapter.getItem(position);
        imgLoader.setVisibility(View.VISIBLE);
        //String REGISTER_URL =    "http://43.227.135.110:3233/app/canceltrip?am_ven_veh_slno="+trip.getAm_ven_veh_number()+"trip_id="+trip.getId()+"VUID="+appConfig.getVendorUID();
        String REGISTER_URL =    "http://10.10.11.68:8080/app/canceltrip?am_ven_veh_slno="+trip.getAm_ven_veh_slno()+"&trip_id="+trip.getId()+"&VUID="+appConfig.getVendorUID();
        Log.d("Vehicles URL: ",REGISTER_URL);
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest stringRequest = new StringRequest(Request.Method.GET, REGISTER_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            Log.d("Vehicles Response: ",response);
                            JSONObject obj = new JSONObject(response);
                            if(obj.getBoolean("status")){
                                imgLoader.setVisibility(View.GONE);
                                tripsAdapter.removeItem(position);
                                tripsAdapter.notifyItemRemoved(position);
                                Toast.makeText(StatusActivity.this,"Trip ID: "+trip.getId()+" cancelled!",Toast.LENGTH_LONG).show();
                            }
                            else{
                                //Snackbar.make(view, obj.getString("message"), Snackbar.LENGTH_SHORT).show();
                                Toast.makeText(StatusActivity.this,obj.getString("message"),Toast.LENGTH_LONG).show();
                                imgLoader.setVisibility(View.GONE);
                            }

                        } catch (JSONException e) {
                            //Snackbar.make(view, e.toString(), Snackbar.LENGTH_SHORT).show();
                            Toast.makeText(StatusActivity.this,e.toString(),Toast.LENGTH_LONG).show();
                            imgLoader.setVisibility(View.GONE);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(StatusActivity.this,error.toString(),Toast.LENGTH_LONG).show();
                        imgLoader.setVisibility(View.GONE);
                    }
                });

        requestQueue.add(stringRequest);
    }
}