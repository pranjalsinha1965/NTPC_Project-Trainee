package com.ntpc.vehicleq.helpers;

import android.content.Context;
import android.content.SharedPreferences;

public class AppSharedPreferences {
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    public static final String mypreference = "ntpcsimhadriashjilani";
    public AppSharedPreferences(Context context){
        sharedpreferences = context.getSharedPreferences(mypreference,
                Context.MODE_PRIVATE);
        editor = sharedpreferences.edit();
    }

    public void setLoginStatus(boolean z) {
        this.editor.putBoolean("loginstatus", z);
        this.editor.commit();
    }

    public boolean getLoginStatus() {
        return this.sharedpreferences.getBoolean("loginstatus", false);
    }

    public void setMobile(String str) {
        this.editor.putString("mobile", str);
        this.editor.commit();
    }

    public String getMobile() {
        return this.sharedpreferences.getString("mobile", null);
    }

    public void setToken(String str) {
        this.editor.putString("token", str);
        this.editor.commit();
    }

    public String getToken() {
        return this.sharedpreferences.getString("token", null);
    }

    public void setDeviceID(String str) {
        this.editor.putString("DeviceID", str);
        this.editor.commit();
    }

    public String getDeviceID() {
        return this.sharedpreferences.getString("DeviceID", null);
    }

    public void setVendorUID(String str) {
        this.editor.putString("VendorUID", str);
        this.editor.commit();
    }

    public String getVendorUID() {
        return this.sharedpreferences.getString("VendorUID", null);
    }

    public void setOTP(String str) {
        this.editor.putString("otp", str);
        this.editor.commit();
    }

    public String getOTP() {
        return this.sharedpreferences.getString("otp", null);
    }

    public void setAshId(String str) {
        this.editor.putString("ashid", str);
        this.editor.commit();
    }

    public String getAshId() {
        return this.sharedpreferences.getString("ashid", null);
    }

}
