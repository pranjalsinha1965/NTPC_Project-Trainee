package com.ntpc.vehicleq;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatImageView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.android.material.textfield.TextInputEditText;
import com.ntpc.vehicleq.helpers.AppSharedPreferences;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

public class ResetpasswordActivity extends AppCompatActivity {
    AppSharedPreferences appConfig;
    AppCompatImageView btnBack;
    AppCompatButton btnSubmit;
    AppCompatImageView imgLoader;
    TextInputEditText txtConfirmPassword;
    TextInputEditText txtPassword;

    @Override
    public void onCreate(Bundle bundle) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(bundle);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_resetpassword);
        getSupportActionBar().hide();
        btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               goBack();
            }
        });
        appConfig = new AppSharedPreferences(getApplicationContext());
        btnSubmit = findViewById(R.id.button_submit);
        imgLoader = findViewById(R.id.loader);
        Glide.with(this).load(R.raw.loader).into(imgLoader);
        txtPassword = findViewById(R.id.txt_password);
        txtConfirmPassword = findViewById(R.id.txt_confirm_password);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(txtPassword.getText().toString().trim()) && txtPassword.getText().length() < 6) {
                    Toast.makeText(getApplicationContext(), "Please Enter Valid Password", Toast.LENGTH_SHORT).show();
                    txtPassword.setFocusable(true);
                } else if (TextUtils.isEmpty(txtConfirmPassword.getText().toString().trim()) && txtConfirmPassword.getText().length() < 6) {
                    Toast.makeText(getApplicationContext(), "Please Enter Valid Confirm Password", Toast.LENGTH_SHORT).show();
                    txtConfirmPassword.setFocusable(true);
                } else if (!txtPassword.getText().toString().equals(txtConfirmPassword.getText().toString())) {
                    Toast.makeText(getApplicationContext(), "Passwords doesn't match", Toast.LENGTH_SHORT).show();
                    txtConfirmPassword.setFocusable(true);
                } else {
                    postData(view);
                }
            }
        });
    }

    public void postData(View view) {
        imgLoader.setVisibility(View.GONE);
        //Volley.newRequestQueue(getApplicationContext()).add(new StringRequest(Request.Method.POST, "http://43.227.135.110:3233/app/updatepassword", new Response.Listener<String>() {
        Volley.newRequestQueue(getApplicationContext()).add(new StringRequest(Request.Method.POST, "http://10.10.11.68:8080/app/updatepassword", new Response.Listener<String>() {
            @Override
            public void onResponse(String str) {
                Log.d("Login Response: ", str);
                try {
                    JSONObject jSONObject = new JSONObject(str);
                    if (jSONObject.getBoolean("status")) {
                        try {
                            Intent intent = new Intent(ResetpasswordActivity.this, LoginActivity.class);
                            imgLoader.setVisibility(View.GONE);
                            btnSubmit.setVisibility(View.VISIBLE);
                            startActivity(intent);
                        } catch (Exception e) {
                            imgLoader.setVisibility(View.GONE);
                            btnSubmit.setVisibility(View.VISIBLE);
                            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        imgLoader.setVisibility(View.GONE);
                        btnSubmit.setVisibility(View.VISIBLE);
                        Toast.makeText(ResetpasswordActivity.this, jSONObject.getString("vendor"), Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e2) {
                    imgLoader.setVisibility(View.GONE);
                    btnSubmit.setVisibility(View.VISIBLE);
                    Toast.makeText(ResetpasswordActivity.this, e2.toString(), Toast.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                imgLoader.setVisibility(View.GONE);
                btnSubmit.setVisibility(View.VISIBLE);
                Toast.makeText(ResetpasswordActivity.this, volleyError.toString(), Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                HashMap hashMap = new HashMap();
                hashMap.put("UserName", appConfig.getAshId());
                hashMap.put("device_id", appConfig.getDeviceID());
                hashMap.put("password", txtPassword.getText().toString().trim());
                return hashMap;
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        goBack();
    }

    void goBack() {
        startActivity(new Intent(this, LoginActivity.class));
    }
}
