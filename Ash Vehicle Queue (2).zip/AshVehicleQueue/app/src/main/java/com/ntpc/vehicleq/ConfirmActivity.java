package com.ntpc.vehicleq;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.core.app.NotificationCompat;
import androidx.fragment.app.FragmentActivity;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.messaging.Constants;
import com.google.gson.GsonBuilder;
import com.ntpc.vehicleq.helpers.AppSharedPreferences;
import com.ntpc.vehicleq.models.Vehicles;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: C:\Users\simhadriadmin\Desktop\4-APK\classes.dex */
public class ConfirmActivity extends AppCompatActivity {
    LinearLayoutCompat _layoutSendOTP;
    LinearLayoutCompat _layoutVerifyOTP;
    AppSharedPreferences appConfig;
    AppCompatImageView btnBack;
    AppCompatButton btnResendOtp;
    AppCompatButton btnSendOtp;
    AppCompatButton btnVerify;
    List<Vehicles> chckedVehiclesList = new ArrayList();
    AppCompatImageView imgLoader;
    AppCompatTextView txtMobile;
    TextInputEditText txtOTP;
    AppCompatTextView txtResentOTPTimer;

    @Override
    public void onCreate(Bundle bundle) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(bundle);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_confirm);
        getSupportActionBar().hide();
        this.appConfig = new AppSharedPreferences(getApplicationContext());
        btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goBack();
            }
        });
        _layoutSendOTP = findViewById(R.id.layout_send_otp);
        _layoutVerifyOTP = findViewById(R.id.layout_verify_otp);
        _layoutVerifyOTP.setVisibility(View.GONE);
        _layoutSendOTP.setVisibility(View.VISIBLE);
        txtOTP = findViewById(R.id.txt_otp);
        txtMobile = findViewById(R.id.txtview_vendor_mobile);
        txtResentOTPTimer = findViewById(R.id.txtResentOTPTimer);
        imgLoader = findViewById(R.id.loader);
        Glide.with(this).load(R.raw.loader).into(imgLoader);
        btnSendOtp = findViewById(R.id.button_send_otp);
        btnSendOtp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendOtp(view);
            }
        });
        btnVerify = findViewById(R.id.button_verify_otp);
        btnVerify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(txtOTP.getText().toString().trim()) || txtOTP.getText().toString().length() < 6) {
                    Toast.makeText(ConfirmActivity.this, "Please Enter Valid OTP", Toast.LENGTH_LONG).show();
                    txtOTP.setFocusable(true);
                    return;
                }
                verifyOTP(view);
            }
        });
        btnResendOtp = findViewById(R.id.button_resend_otp);
        btnResendOtp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendOtp(view);
            }
        });
        txtMobile.setText(appConfig.getMobile());
        btnResendOtp.setVisibility(View.GONE);
        btnVerify.setVisibility(View.GONE);
        _layoutSendOTP.setVisibility(View.VISIBLE);
        _layoutVerifyOTP.setVisibility(View.GONE);
        txtResentOTPTimer.setVisibility(View.GONE);
        chckedVehiclesList = Arrays.asList((Vehicles[]) new GsonBuilder().create().fromJson(getIntent().getExtras().getString("user_ash_request"), Vehicles[].class));
    }

    public void placeRequest(String str) {
        this.imgLoader.setVisibility(View.VISIBLE);
        //String str2 = "http://43.227.135.110:3233/app/addtrip?am_ven_veh_slno=" + str;
        String str2 = "http://10.10.11.68:8080/app/addtrip?am_ven_veh_slno=" + str;
        Log.d("Vehicles URL: ", str2);
        Volley.newRequestQueue(getApplicationContext()).add(new StringRequest(Request.Method.GET, str2, new Response.Listener<String>() {
            @Override // com.android.volley.Response.Listener
            public void onResponse(String str3) {
                try {
                    Log.d("Request Response: ", str3);
                    JSONObject jSONObject = new JSONObject(str3);
                    if (jSONObject.getBoolean("status")) {
                        Toast.makeText(ConfirmActivity.this, jSONObject.getString("message"), Toast.LENGTH_LONG).show();
                        imgLoader.setVisibility(View.GONE);
                    } else {
                        Toast.makeText(ConfirmActivity.this, jSONObject.getString("message"), Toast.LENGTH_LONG).show();
                        imgLoader.setVisibility(View.GONE);
                    }
                    ConfirmActivity.this.startActivity(new Intent(ConfirmActivity.this, StatusActivity.class));
                } catch (JSONException e) {
                    Toast.makeText(ConfirmActivity.this, e.toString(), Toast.LENGTH_LONG).show();
                    imgLoader.setVisibility(View.GONE);
                }
            }
        }, new Response.ErrorListener() { // from class: com.ntpc.vehicleq.ConfirmActivity.6
            @Override // com.android.volley.Response.ErrorListener
            public void onErrorResponse(VolleyError volleyError) {
                Toast.makeText(ConfirmActivity.this, volleyError.toString(), Toast.LENGTH_LONG).show();
                imgLoader.setVisibility(View.GONE);
            }
        }));
    }

    public void sendOtp(View view) {
        //final String str = "http://43.227.135.110:3233/app/sendrequestotp?mobile=" + this.appConfig.getMobile();
        final String str = "http://10.10.11.68:8080/app/sendrequestotp?mobile=" + this.appConfig.getMobile();
        Volley.newRequestQueue(getApplicationContext()).add(new StringRequest(Request.Method.POST, str, new Response.Listener<String>() {
            @Override
            public void onResponse(String str2) {
                Log.d("Response: ", str2);
                try {
                    JSONObject jSONObject = new JSONObject(str2);
                    if (jSONObject.getBoolean("status")) {
                        new CountDownTimer(60000L, 1000L) {
                            @Override
                            public void onTick(long j) {
                                txtResentOTPTimer.setVisibility(View.VISIBLE);
                                txtResentOTPTimer.setText("Resend OTP in " + (j / 1000) + " sec");
                            }

                            @Override
                            public void onFinish() {
                                txtResentOTPTimer.setVisibility(View.GONE);
                                btnResendOtp.setVisibility(View.VISIBLE);
                            }
                        }.start();
                        imgLoader.setVisibility(View.GONE);
                        appConfig.setOTP(jSONObject.getString(Constants.ScionAnalytics.MessageType.DATA_MESSAGE));
                        _layoutSendOTP.setVisibility(View.GONE);
                        _layoutVerifyOTP.setVisibility(View.VISIBLE);
                        btnVerify.setVisibility(View.VISIBLE);
                        Toast.makeText(ConfirmActivity.this, "OTP has sent to " + appConfig.getMobile(), Toast.LENGTH_LONG).show();
                    } else {
                        imgLoader.setVisibility(View.GONE);
                        Toast.makeText(ConfirmActivity.this, jSONObject.getString("message"), Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {
                    imgLoader.setVisibility(View.GONE);
                    Toast.makeText(ConfirmActivity.this, e.toString(), Toast.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() { // from class: com.ntpc.vehicleq.ConfirmActivity.8
            @Override // com.android.volley.Response.ErrorListener
            public void onErrorResponse(VolleyError volleyError) {
                imgLoader.setVisibility(View.GONE);
                Toast.makeText(ConfirmActivity.this, volleyError.toString(), Toast.LENGTH_LONG).show();
            }
        }) { // from class: com.ntpc.vehicleq.ConfirmActivity.9
            @Override // com.android.volley.Request
            protected Map<String, String> getParams() {
                return new HashMap();
            }
        });
    }

    void verifyOTP(View view) {
        if (appConfig.getOTP().equals(txtOTP.getText().toString())) {
            String str = "";
            for (int i = 0; i < chckedVehiclesList.size(); i++) {
                str = str + String.valueOf(chckedVehiclesList.get(i).getAm_ven_veh_slno()) + ",";
            }
            placeRequest(str);
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        super.onBackPressed();
        goBack();
    }

    void goBack() {
        startActivity(new Intent(this, RequestActivity.class));
    }
}
