package com.ntpc.vehicleq.adapters;

import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textview.MaterialTextView;
import com.ntpc.vehicleq.R;
import com.ntpc.vehicleq.models.Trip;
import com.ntpc.vehicleq.models.Vehicles;

import java.util.List;

public class TripsAdapter extends RecyclerView.Adapter<TripsAdapter.TripsViewHolder> {
    private Context _mContext;
    private List<Trip> _tripsList;
    private OnTripCancel _onTripCancel;
    public TripsAdapter(Context mContext,List<Trip> tripsList,OnTripCancel onTripCancel){
        _mContext = mContext;
        _tripsList = tripsList;
        _onTripCancel=onTripCancel;
    }

    @NonNull
    @Override
    public TripsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layout_current_request_vehicles, parent, false);
        return new TripsViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull TripsViewHolder holder, int position) {
        final Trip trip = _tripsList.get(position);
        holder.lblVehicleType.setText(trip.getAm_ven_veh_type());
        holder.lblVehicleNumber.setText(trip.getAm_ven_veh_number());
        holder.lblSlotTime.setText(trip.getRequested_on());
        holder.lblQueueNumber.setText("Queue No. : "+String.valueOf(trip.getQueue_no()));
        holder.lblCapacity.setText("Capacity: "+String.valueOf(trip.getCapacity()) +"T");
    }

    @Override
    public int getItemCount() {
        return _tripsList.size();
    }

    public Trip getItem(int position) { return _tripsList.get(position);}
    public void removeItem(int position) { Trip item = _tripsList.remove(position);}

    public class TripsViewHolder extends RecyclerView.ViewHolder {
        MaterialTextView lblVehicleNumber,lblCapacity,lblVehicleType,lblQueueNumber,lblSlotTime;
        AppCompatButton btnCancelTrip;
        public TripsViewHolder(@NonNull View itemView) {
            super(itemView);
            lblCapacity = itemView.findViewById(R.id.trip_vehicle_capacity);
            lblQueueNumber=itemView.findViewById(R.id.trip_vehicle_queue_number);
            lblSlotTime=itemView.findViewById(R.id.trip_vehicle_slot_time);
            lblVehicleNumber=itemView.findViewById(R.id.trip_vehicle_number);
            lblVehicleType=itemView.findViewById(R.id.trip_vehicle_type);
            btnCancelTrip = itemView.findViewById(R.id.trip_vehicle_cancel_button);
            btnCancelTrip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(_mContext);
                    builder.setTitle("Request Cancel");
                    builder.setMessage("Do you want to cancel the request ?");
                    builder.setCancelable(false);
                    builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            //_onTripCancel.onTripCancel(getAdapterPosition());
                            _onTripCancel.onTripCancel(getLayoutPosition());
                        }
                    });
                    builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.cancel();
                        }
                    });
                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }
            });
        }
    }

    public interface OnTripCancel{
        void onTripCancel(int position);
    }
}
