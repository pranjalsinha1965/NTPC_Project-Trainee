package com.ntpc.vehicleq.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textview.MaterialTextView;
import com.ntpc.vehicleq.R;
import com.ntpc.vehicleq.models.Vehicles;

import java.util.List;

public class NewRequestVehiclesAdapter extends RecyclerView.Adapter<NewRequestVehiclesAdapter.NewRequestVehiclesViewHolder> {
    private Context _mContext;
    private List<Vehicles> _vehiclesList;
    private OnVehicleSelectionChanged _onVehicleSelectionChanged;
    public NewRequestVehiclesAdapter(Context mContext,List<Vehicles> vehiclesList,OnVehicleSelectionChanged onVehicleSelectionChanged){
        _mContext = mContext;
        _vehiclesList = vehiclesList;
        _onVehicleSelectionChanged = onVehicleSelectionChanged;
    }
    @NonNull
    @Override
    public NewRequestVehiclesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layout_new_request_vehicle, parent, false);
        return new NewRequestVehiclesViewHolder(itemView,_onVehicleSelectionChanged);
    }

    @Override
    public void onBindViewHolder(@NonNull NewRequestVehiclesViewHolder holder, int position) {
        final Vehicles vehicle = _vehiclesList.get(position);
        holder.lblVehicleNumber.setText(vehicle.getAm_ven_veh_number());
        holder.lblVehicleType.setText(vehicle.getAm_ven_veh_type());
        holder.lblVehicleCapacity.setText("Capacity: "+String.valueOf(vehicle.getCapacity())+"T" );
    }

    @Override
    public int getItemCount() {
        return _vehiclesList.size();
    }

    public class NewRequestVehiclesViewHolder extends RecyclerView.ViewHolder {
        MaterialTextView lblVehicleNumber,lblVehicleType,lblVehicleCapacity;
        CheckBox cbIsVehicleRequested;
        private OnVehicleSelectionChanged _vonVehicleSelectionChanged;
        public NewRequestVehiclesViewHolder(@NonNull View itemView,OnVehicleSelectionChanged onVehicleSelectionChanged) {
            super(itemView);

            lblVehicleCapacity = itemView.findViewById(R.id.request_vehicle_capacity);
            lblVehicleNumber = itemView.findViewById(R.id.request_vehicle_number);
            lblVehicleType = itemView.findViewById(R.id.request_vehicle_type);
            cbIsVehicleRequested = itemView.findViewById(R.id.request_vehicle_is_selected);
            cbIsVehicleRequested.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    boolean checked = ((CheckBox) view).isChecked();
                    _onVehicleSelectionChanged.onVehicleSelectionChanged(getAdapterPosition(),checked);
                }
            });
        }
    }

    public interface OnVehicleSelectionChanged{
        void onVehicleSelectionChanged(int position,boolean isChecked);
    }
}
