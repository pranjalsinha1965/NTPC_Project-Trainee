package com.ntpc.vehicleq.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.android.material.textview.MaterialTextView;
import com.ntpc.vehicleq.LandingActivity;
import com.ntpc.vehicleq.LoginActivity;
import com.ntpc.vehicleq.R;
import com.ntpc.vehicleq.RequestActivity;
import com.ntpc.vehicleq.StatusActivity;
import com.ntpc.vehicleq.helpers.AppSharedPreferences;
import com.ntpc.vehicleq.models.Trip;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    private AppCompatButton btnSubmit, btnViewAll, btnRefresh;
    AppCompatImageView imgLoader;
    AppSharedPreferences appConfig;
    MaterialTextView lblQueueNumber, lblVehicleNumber, lblSlotTime, lblCurrentQ;
    CardView cardCurrentQueue;
    List<Trip> tripsList = new ArrayList<>();

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
       /* homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);*/
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        imgLoader = root.findViewById(R.id.loader);
        Glide.with(this)
                .load(R.raw.loader)
                .into(imgLoader);
        imgLoader.setVisibility(View.GONE);
        appConfig = new AppSharedPreferences(getContext());
        lblQueueNumber = root.findViewById(R.id.home_queue_number);
        lblVehicleNumber = root.findViewById(R.id.home_vehicle_number);
        lblSlotTime = root.findViewById(R.id.home_slot_time);
        lblCurrentQ = root.findViewById(R.id.label_current_q);
        cardCurrentQueue = root.findViewById(R.id.home_current_queue_details);
        btnSubmit = root.findViewById(R.id.button_new_request);
        btnRefresh = root.findViewById(R.id.btn_current_q_refresh);
        btnRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getCurrentQ();
            }
        });
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), RequestActivity.class);
                startActivity(intent);
            }
        });
        btnViewAll = root.findViewById(R.id.button_view_all);
        btnViewAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), StatusActivity.class);
                startActivity(intent);
            }
        });
       /* final TextView textView = root.findViewById(R.id.text_home);
        homeViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });*/
        getVehicles();
        getCurrentQ();
        return root;
    }

    public void getVehicles() {
        cardCurrentQueue.setVisibility(View.INVISIBLE);
        imgLoader.setVisibility(View.VISIBLE);
        //String REGISTER_URL = "http://43.227.135.110:3233/app/currenttrips?uid=" + appConfig.getVendorUID();
        String REGISTER_URL = "http://10.10.11.68:8080/app/currenttrips?uid=" + appConfig.getVendorUID();
        Log.d("Vehicles URL: ", REGISTER_URL);
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        StringRequest stringRequest = new StringRequest(Request.Method.GET, REGISTER_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            Log.d("Vehicles Response: ", response);
                            JSONObject obj = new JSONObject(response);
                            if (obj.getBoolean("status")) {


                                JSONArray objVehicles = obj.getJSONArray("vendor");
                                for (int i = 0; i < objVehicles.length(); i++) {
                                    JSONObject jsonVehicle = objVehicles.getJSONObject(i);
                                    Trip trp = new Trip();
                                    trp.setAm_ven_name(jsonVehicle.getString("am_ven_name"));
                                    trp.setAm_ven_unique_id(jsonVehicle.getInt("am_ven_unique_id"));
                                    trp.setAm_ven_veh_number(jsonVehicle.getString("am_ven_veh_number"));
                                    trp.setAm_ven_veh_status(jsonVehicle.getString("am_ven_veh_status"));
                                    trp.setAm_ven_veh_type(jsonVehicle.getString("am_ven_veh_type"));
                                    trp.setCapacity(jsonVehicle.getInt("capacity"));
                                    trp.setId(jsonVehicle.getInt("id"));
                                    trp.setQueue_no(jsonVehicle.getInt("queue_no"));
                                    trp.setRequested_on(jsonVehicle.getString("slot_time"));
                                    if (jsonVehicle.getString("am_ven_veh_status").equals("ON")) {

                                    }
                                    tripsList.add(trp);
                                    lblQueueNumber.setText(String.valueOf(trp.getQueue_no()));
                                    lblSlotTime.setText(trp.getRequested_on());
                                    lblVehicleNumber.setText(trp.getAm_ven_veh_number().trim());
                                    cardCurrentQueue.setVisibility(View.VISIBLE);
                                }

                                imgLoader.setVisibility(View.GONE);
                            } else {
                                //Snackbar.make(view, obj.getString("message"), Snackbar.LENGTH_SHORT).show();
                                Toast.makeText(getContext(), obj.getString("message"), Toast.LENGTH_LONG).show();
                                cardCurrentQueue.setVisibility(View.GONE);
                                imgLoader.setVisibility(View.GONE);
                            }

                        } catch (JSONException e) {
                            //Snackbar.make(view, e.toString(), Snackbar.LENGTH_SHORT).show();
                            Toast.makeText(getContext(), e.toString(), Toast.LENGTH_LONG).show();
                            cardCurrentQueue.setVisibility(View.GONE);
                            imgLoader.setVisibility(View.GONE);
                        }

                        // Toast.makeText(RequestActivity.this,response,Toast.LENGTH_LONG).show();

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getContext(), error.toString(), Toast.LENGTH_LONG).show();
                        cardCurrentQueue.setVisibility(View.INVISIBLE);
                        imgLoader.setVisibility(View.GONE);
                        //Snackbar.make(view, error.toString(), Snackbar.LENGTH_SHORT).show();
                    }
                })
   /*     {
            @Override
            protected Map<String,String> getParams(){
                Map<String,String> params = new HashMap<String, String>();
                params.put("UserName",txtUsername.getText().toString().trim());
                params.put("Password",txtPassword.getText().toString().trim());

                return params;
            }

        }*/;


        requestQueue.add(stringRequest);
    }


    public void getCurrentQ() {

        imgLoader.setVisibility(View.VISIBLE);
        //String REGISTER_URL = "http://43.227.135.110:3233/app/currentq";
        String REGISTER_URL = "http://10.10.11.68:8080/app/currentq";
        Log.d("Vehicles URL: ", REGISTER_URL);
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        StringRequest stringRequest = new StringRequest(Request.Method.GET, REGISTER_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            Log.d("Q Response: ", response);
                            JSONObject obj = new JSONObject(response);
                            if (obj.getBoolean("status")) {


                                JSONObject objQ = obj.getJSONObject("vendor");
                                try {
                                    lblCurrentQ.setText(String.valueOf( objQ.getInt("queue_no")));
                                } catch (Exception ex) {
                                    String err = ex.toString();
                                }

                                imgLoader.setVisibility(View.GONE);
                            } else {
                                //Snackbar.make(view, obj.getString("message"), Snackbar.LENGTH_SHORT).show();
                                Toast.makeText(getContext(), obj.getString("message"), Toast.LENGTH_LONG).show();

                                imgLoader.setVisibility(View.GONE);
                            }

                        } catch (Exception e) {
                            //Snackbar.make(view, e.toString(), Snackbar.LENGTH_SHORT).show();
                            Toast.makeText(getContext(), e.toString(), Toast.LENGTH_LONG).show();

                            imgLoader.setVisibility(View.GONE);
                        }

                        // Toast.makeText(RequestActivity.this,response,Toast.LENGTH_LONG).show();

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getContext(), error.toString(), Toast.LENGTH_LONG).show();
                        cardCurrentQueue.setVisibility(View.INVISIBLE);
                        imgLoader.setVisibility(View.GONE);
                        //Snackbar.make(view, error.toString(), Snackbar.LENGTH_SHORT).show();
                    }
                })
   /*     {
            @Override
            protected Map<String,String> getParams(){
                Map<String,String> params = new HashMap<String, String>();
                params.put("UserName",txtUsername.getText().toString().trim());
                params.put("Password",txtPassword.getText().toString().trim());

                return params;
            }

        }*/;


        requestQueue.add(stringRequest);
    }


}