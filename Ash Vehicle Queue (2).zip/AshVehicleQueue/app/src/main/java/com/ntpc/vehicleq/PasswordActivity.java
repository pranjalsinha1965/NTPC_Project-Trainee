package com.ntpc.vehicleq;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.app.NotificationCompat;
import androidx.fragment.app.FragmentActivity;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.ntpc.vehicleq.helpers.AppSharedPreferences;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;


public class PasswordActivity extends AppCompatActivity {
    AppSharedPreferences appConfig;
    AppCompatImageView btnBack;
    AppCompatButton btnForgotPassword;
    AppCompatButton btnSubmit;
    AppCompatImageView imgLoader;
    TextInputEditText txtPassword;


    @Override
    public void onCreate(Bundle bundle) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(bundle);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_password);
        getSupportActionBar().hide();
        appConfig = new AppSharedPreferences(getApplicationContext());
        btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goBack();
            }
        });
        imgLoader = findViewById(R.id.loader);
        Glide.with( this).load(R.raw.loader).into(imgLoader);
        btnSubmit = findViewById(R.id.button_submit_password);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(txtPassword.getText().toString().trim())) {
                    Toast.makeText(PasswordActivity.this, "Please Enter Valid Password", Toast.LENGTH_LONG).show();
                    txtPassword.setFocusable(true);
                    imgLoader.setVisibility(View.GONE);
                    btnSubmit.setVisibility(View.VISIBLE);
                    return;
                }
               //postData(view);
                postJSONData(view);
            }
        });
        txtPassword = findViewById(R.id.txt_password);
        btnForgotPassword = findViewById(R.id.button_forgot_password);

        btnForgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(PasswordActivity.this, OTPActivity.class));
            }
        });
    }

    public void postData(View view) {
        imgLoader.setVisibility(View.VISIBLE);
        //Volley.newRequestQueue(getApplicationContext()).add(new StringRequest(Request.Method.POST, "http://43.227.135.110:3233/app/vendorlogin", new Response.Listener<String>() {
        Volley.newRequestQueue(getApplicationContext()).add(new StringRequest(Request.Method.POST, "http://10.10.11.68:8080/app/vendorlogin", new Response.Listener<String>() {
            @Override
            public void onResponse(String str) {
                Log.d("Login Response: ", str);
                try {
                    JSONObject jSONObject = new JSONObject(str);
                    if (jSONObject.getBoolean("status")) {
                        try {
                            JSONObject jSONObject2 = jSONObject.getJSONObject("vendor");
                            if (jSONObject2 != null) {
                                Intent intent = new Intent(PasswordActivity.this, LandingActivity.class);
                                imgLoader.setVisibility(View.GONE);
                                appConfig.setLoginStatus(true);
                                appConfig.setVendorUID(String.valueOf(jSONObject2.getInt("am_ven_slno")));
                                startActivity(intent);
                            } else {
                                imgLoader.setVisibility(View.GONE);
                                btnSubmit.setVisibility(View.VISIBLE);
                                Toast.makeText(PasswordActivity.this, "Invalid Details", Toast.LENGTH_LONG).show();
                            }
                        } catch (Exception e) {
                            imgLoader.setVisibility(View.GONE);
                            btnSubmit.setVisibility(View.VISIBLE);
                            Toast.makeText(PasswordActivity.this, e.toString(), Toast.LENGTH_LONG).show();
                        }
                    } else {
                        imgLoader.setVisibility(View.GONE);
                        btnSubmit.setVisibility(View.VISIBLE);
                        Toast.makeText(PasswordActivity.this, jSONObject.getString("vendor"), Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e2) {
                    imgLoader.setVisibility(View.GONE);
                    btnSubmit.setVisibility(View.VISIBLE);
                    Toast.makeText(PasswordActivity.this, e2.toString(), Toast.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                imgLoader.setVisibility(View.GONE);
                btnSubmit.setVisibility(View.VISIBLE);
                Toast.makeText(PasswordActivity.this, volleyError.toString(), Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                HashMap hashMap = new HashMap();
                hashMap.put("UserName", appConfig.getAshId());
                hashMap.put("device_id", appConfig.getDeviceID());
                hashMap.put("Password", txtPassword.getText().toString().trim());
                Log.d("ReqParams", hashMap.toString());
                return hashMap;
            }
        });
    }

    public void postJSONData(View view) {
        String REGISTER_URL = "http://10.10.11.68:8080/app/vendorlogin";
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("UserName", appConfig.getAshId());
        params.put("device_id", appConfig.getDeviceID());
        params.put("Password", txtPassword.getText().toString().trim());
        JSONObject jsonBody = new JSONObject(params);
        JsonRequest jsonRequest = new JsonRequest(Request.Method.POST, REGISTER_URL, jsonBody.toString(),
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String str) {
                        Log.d("Login Response: ", str);
                        try {
                            JSONObject jSONObject = new JSONObject(str);
                            if (jSONObject.getBoolean("status")) {
                                try {
                                    JSONObject jSONObject2 = jSONObject.getJSONObject("vendor");
                                    if (jSONObject2 != null) {
                                        Intent intent = new Intent(PasswordActivity.this, LandingActivity.class);
                                        imgLoader.setVisibility(View.GONE);
                                        appConfig.setLoginStatus(true);
                                        appConfig.setVendorUID(String.valueOf(jSONObject2.getInt("am_ven_slno")));
                                        startActivity(intent);
                                    } else {
                                        imgLoader.setVisibility(View.GONE);
                                        btnSubmit.setVisibility(View.VISIBLE);
                                        Toast.makeText(PasswordActivity.this, "Invalid Details", Toast.LENGTH_LONG).show();
                                    }
                                } catch (Exception e) {
                                    imgLoader.setVisibility(View.GONE);
                                    btnSubmit.setVisibility(View.VISIBLE);
                                    Toast.makeText(PasswordActivity.this, e.toString(), Toast.LENGTH_LONG).show();
                                }
                            } else {
                                imgLoader.setVisibility(View.GONE);
                                btnSubmit.setVisibility(View.VISIBLE);
                                Toast.makeText(PasswordActivity.this, jSONObject.getString("vendor"), Toast.LENGTH_LONG).show();
                            }
                        } catch (Exception e2) {
                            imgLoader.setVisibility(View.GONE);
                            btnSubmit.setVisibility(View.VISIBLE);
                            Toast.makeText(PasswordActivity.this, e2.toString(), Toast.LENGTH_LONG).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                imgLoader.setVisibility(View.GONE);
                btnSubmit.setVisibility(View.VISIBLE);
                Toast.makeText(PasswordActivity.this, volleyError.toString(), Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Response parseNetworkResponse(NetworkResponse response) {
                Log.d("Login Response: ", new String(response.data));
                if (response != null)
                    return Response.success(new String(response.data), null);
                else
                    return Response.error(new VolleyError());
            }
        };
        requestQueue.add(jsonRequest);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        goBack();
    }

    void goBack() {
        startActivity(new Intent(this, LoginActivity.class));
    }
}
