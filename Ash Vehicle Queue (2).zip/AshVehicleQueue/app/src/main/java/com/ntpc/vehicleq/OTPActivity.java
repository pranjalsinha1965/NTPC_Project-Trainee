package com.ntpc.vehicleq;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.core.app.NotificationCompat;
import androidx.fragment.app.FragmentActivity;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.messaging.Constants;
import com.ntpc.vehicleq.helpers.AppSharedPreferences;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;


public class OTPActivity extends AppCompatActivity {
    LinearLayoutCompat _layoutSendOTP;
    LinearLayoutCompat _layoutVerifyOTP;
    AppSharedPreferences appConfig;
    AppCompatImageView btnBack;
    AppCompatButton btnResendOtp;
    AppCompatButton btnSendOtp;
    AppCompatButton btnVerify;
    AppCompatImageView imgLoader;
    AppCompatTextView txtMobile;
    TextInputEditText txtOTP;
    AppCompatTextView txtResentOTPTimer;


    @Override
    public void onCreate(Bundle bundle) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(bundle);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_otpactivity);
        getSupportActionBar().hide();
        appConfig = new AppSharedPreferences(getApplicationContext());
        btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goBack();
            }
        });
        _layoutSendOTP = findViewById(R.id.layout_send_otp);
        _layoutVerifyOTP = findViewById(R.id.layout_verify_otp);
        _layoutVerifyOTP.setVisibility(View.GONE);
        _layoutSendOTP.setVisibility(View.VISIBLE);
        txtOTP = findViewById(R.id.txt_otp);
        txtMobile = findViewById(R.id.txtview_vendor_mobile);
        txtResentOTPTimer = findViewById(R.id.txtResentOTPTimer);
        imgLoader = findViewById(R.id.loader);
        Glide.with(this).load(R.raw.loader).into(imgLoader);
        btnSendOtp = findViewById(R.id.button_send_otp);
        btnSendOtp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendOtp(view);
            }
        });
        btnVerify = findViewById(R.id.button_verify_otp);
        btnVerify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(txtOTP.getText().toString().trim()) || txtOTP.getText().toString().length() < 6) {
                    Toast.makeText(OTPActivity.this, "Please Enter Valid OTP", Toast.LENGTH_LONG).show();
                    txtOTP.setFocusable(true);
                    return;
                }
                verifyOTP(view);
            }
        });
        btnResendOtp = findViewById(R.id.button_resend_otp);
        btnResendOtp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendOtp(view);
            }
        });
        txtMobile.setText(this.appConfig.getMobile());
        btnResendOtp.setVisibility(View.GONE);
        btnVerify.setVisibility(View.GONE);
        _layoutSendOTP.setVisibility(View.VISIBLE);
        _layoutVerifyOTP.setVisibility(View.GONE);
        txtResentOTPTimer.setVisibility(View.GONE);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        goBack();
    }

    public void sendOtp(View view) {
       // final String str = "http://43.227.135.110:3233/app/sendotp?mobile=" + this.appConfig.getMobile();
        final String str = "http://10.10.11.68:8080/app/sendotp?mobile=" + this.appConfig.getMobile();
        Volley.newRequestQueue(getApplicationContext()).add(new StringRequest(Request.Method.POST, str, new Response.Listener<String>() {
            @Override
            public void onResponse(String str2) {
                Log.d("Response: ", str2);
                try {
                    JSONObject jSONObject = new JSONObject(str2);
                    if (jSONObject.getBoolean("status")) {
                        new CountDownTimer(60000L, 1000L) {
                            @Override
                            public void onTick(long j) {
                                txtResentOTPTimer.setVisibility(View.VISIBLE);
                                txtResentOTPTimer.setText("Resend OTP in " + (j / 1000) + " sec");
                            }

                            @Override // android.os.CountDownTimer
                            public void onFinish() {
                                txtResentOTPTimer.setVisibility(View.GONE);
                                btnResendOtp.setVisibility(View.VISIBLE);
                            }
                        }.start();
                        imgLoader.setVisibility(View.GONE);
                        appConfig.setOTP(jSONObject.getString(Constants.ScionAnalytics.MessageType.DATA_MESSAGE));
                        _layoutSendOTP.setVisibility(View.GONE);
                        _layoutVerifyOTP.setVisibility(View.VISIBLE);
                        btnVerify.setVisibility(View.VISIBLE);
                        Toast.makeText(OTPActivity.this, "OTP has sent to " + appConfig.getMobile(), Toast.LENGTH_LONG).show();
                    } else {
                        imgLoader.setVisibility(View.GONE);
                        Toast.makeText(OTPActivity.this, jSONObject.getString("message"), Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {
                    imgLoader.setVisibility(View.GONE);
                    Toast.makeText(OTPActivity.this, e.toString(), Toast.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                imgLoader.setVisibility(View.GONE);
                Toast.makeText(OTPActivity.this, volleyError.toString(), Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                return new HashMap();
            }
        });
    }

    void verifyOTP(View view) {
        if (appConfig.getOTP().equals(txtOTP.getText().toString())) {
            Intent intent = new Intent(OTPActivity.this, ResetpasswordActivity.class);
            imgLoader.setVisibility(View.GONE);
            startActivity(intent);
        }
    }

    void goBack() {
        startActivity(new Intent(OTPActivity.this, LoginActivity.class));
    }
}