package com.ntpc.vehicleq;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.exifinterface.media.ExifInterface;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.android.material.textview.MaterialTextView;
import com.google.gson.Gson;
import com.ntpc.vehicleq.adapters.NewRequestVehiclesAdapter;
import com.ntpc.vehicleq.helpers.AppSharedPreferences;
import com.ntpc.vehicleq.models.Vehicles;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class RequestActivity extends AppCompatActivity implements NewRequestVehiclesAdapter.OnVehicleSelectionChanged {
    AppSharedPreferences appConfig;
    AppCompatImageView btnBack;
    AppCompatButton btnSubmit;
    AppCompatImageView imgLoader;
    MaterialTextView lblTotalCapacity;
    private NewRequestVehiclesAdapter vehiclesAdapter;
    private RecyclerView vehiclesRecyclerView;
    List<Vehicles> vehiclesList = new ArrayList();
    List<Vehicles> chckedVehiclesList = new ArrayList();


    @Override
    public void onCreate(Bundle bundle) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(bundle);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_request);
        setTitle("New Request");
        getSupportActionBar().hide();
        appConfig = new AppSharedPreferences(getApplicationContext());
        btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goBack();
            }
        });
        imgLoader = findViewById(R.id.loader);
        Glide.with(this).load(R.raw.loader).into(imgLoader);
        imgLoader.setVisibility(View.GONE);
        lblTotalCapacity = findViewById(R.id.new_request_total_capacity);
        btnSubmit = findViewById(R.id.button_submit);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (chckedVehiclesList.size() > 0) {
                    Intent intent = new Intent(RequestActivity.this, ConfirmActivity.class);
                    intent.putExtra("user_ash_request", new Gson().toJson(chckedVehiclesList));
                    startActivity(intent);
                    return;
                }
                Toast.makeText(RequestActivity.this, "Please select minimum one vehicle", Toast.LENGTH_SHORT).show();
            }
        });
        vehiclesRecyclerView = findViewById(R.id.recyclerview_new_requestvehicles);
        vehiclesList.clear();
        getVehicles();
    }

    public void getVehicles() {
        this.imgLoader.setVisibility(View.VISIBLE);
        //String str = "http://43.227.135.110:3233/app/availablevehicles?uid=" + appConfig.getVendorUID();
        String str = "http://10.10.11.68:8080/app/availablevehicles?uid=" + appConfig.getVendorUID();
        Log.d("Vehicles URL: ", str);
        Volley.newRequestQueue(getApplicationContext()).add(new StringRequest(Request.Method.GET, str, new Response.Listener<String>() {
            @Override
            public void onResponse(String str2) {
                try {
                    Log.d("Vehicles Response: ", str2);
                    JSONObject jSONObject = new JSONObject(str2);
                    if (jSONObject.getBoolean("status")) {
                        JSONArray jSONArray = jSONObject.getJSONArray("vendor");
                        for (int i = 0; i < jSONArray.length(); i++) {
                            JSONObject jSONObject2 = jSONArray.getJSONObject(i);
                            Vehicles vehicles = new Vehicles();
                            vehicles.setAm_ven_unique_id(jSONObject2.getInt("am_ven_unique_id"));
                            vehicles.setAm_ven_veh_license(jSONObject2.getString("am_ven_veh_license"));
                            vehicles.setAm_ven_veh_unique_id(jSONObject2.getInt("am_ven_veh_unique_id"));
                            vehicles.setAm_ven_veh_number(jSONObject2.getString("am_ven_veh_number"));
                            vehicles.setCapacity(jSONObject2.getInt("capacity"));
                            vehicles.setAm_ven_veh_type(jSONObject2.getString("am_ven_veh_type"));
                            vehicles.setAm_ven_veh_slno(jSONObject2.getInt("am_ven_veh_slno"));
                            vehicles.setAm_ven_veh_status(jSONObject2.getString("am_ven_veh_status"));
                            vehicles.setAm_ven_veh_status(jSONObject2.getString("is_trip_requested"));
                            vehiclesList.add(vehicles);
                        }
                        List<Vehicles> list = vehiclesList;
                        final RequestActivity requestActivity2 = RequestActivity.this;
                        vehiclesAdapter = new NewRequestVehiclesAdapter(getApplicationContext(), list, new NewRequestVehiclesAdapter.OnVehicleSelectionChanged() {
                            @Override
                            public final void onVehicleSelectionChanged(int i2, boolean z) {
                                RequestActivity.this.onVehicleSelectionChanged(i2, z);
                            }
                        });
                        vehiclesRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                        vehiclesRecyclerView.setAdapter(vehiclesAdapter);
                        imgLoader.setVisibility(View.GONE);
                        return;
                    }
                    Toast.makeText(RequestActivity.this, jSONObject.getString("message"), Toast.LENGTH_LONG).show();
                    imgLoader.setVisibility(View.GONE);
                } catch (JSONException e) {
                    Toast.makeText(RequestActivity.this, e.toString(), Toast.LENGTH_LONG).show();
                    imgLoader.setVisibility(View.GONE);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                Toast.makeText(RequestActivity.this, volleyError.toString(), Toast.LENGTH_LONG).show();
                imgLoader.setVisibility(View.GONE);
            }
        }));
    }

    public void placeRequest(String str) {
        this.imgLoader.setVisibility(View.VISIBLE);
        //String str2 = "http://43.227.135.110:3233/app/addtrip?am_ven_veh_slno=" + str;
        String str2 = "http://10.10.11.68:8080/app/addtrip?am_ven_veh_slno=" + str;
        Log.d("Vehicles URL: ", str2);
        Volley.newRequestQueue(getApplicationContext()).add(new StringRequest(Request.Method.GET, str2, new Response.Listener<String>() {
            @Override
            public void onResponse(String str3) {
                try {
                    Log.d("Request Response: ", str3);
                    JSONObject jSONObject = new JSONObject(str3);
                    if (jSONObject.getBoolean("status")) {
                        Toast.makeText(RequestActivity.this, jSONObject.getString("message"), Toast.LENGTH_LONG).show();
                        imgLoader.setVisibility(View.GONE);
                    } else {
                        Toast.makeText(RequestActivity.this, jSONObject.getString("message"), Toast.LENGTH_LONG).show();
                        imgLoader.setVisibility(View.GONE);
                    }
                    startActivity(new Intent(RequestActivity.this, LandingActivity.class));
                } catch (JSONException e) {
                    Toast.makeText(RequestActivity.this, e.toString(), Toast.LENGTH_LONG).show();
                    imgLoader.setVisibility(View.GONE);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                Toast.makeText(RequestActivity.this, volleyError.toString(), Toast.LENGTH_LONG).show();
                imgLoader.setVisibility(View.GONE);
            }
        }));
    }

    @Override
    public void onVehicleSelectionChanged(int i, boolean z) {
        if (z) {
            chckedVehiclesList.add(vehiclesList.get(i));
            int i2 = 0;
            for (int i3 = 0; i3 < chckedVehiclesList.size(); i3++) {
                i2 += chckedVehiclesList.get(i3).getCapacity();
            }
            MaterialTextView materialTextView = this.lblTotalCapacity;
            materialTextView.setText(String.valueOf(i2) + ExifInterface.GPS_DIRECTION_TRUE);
            return;
        }
        chckedVehiclesList.remove(vehiclesList.get(i));
        lblTotalCapacity.setText("0T");
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        super.onBackPressed();
        goBack();
    }

    void goBack() {
        startActivity(new Intent(this, LandingActivity.class));
    }
}